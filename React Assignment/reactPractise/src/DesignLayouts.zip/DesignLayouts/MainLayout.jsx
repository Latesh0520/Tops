import Design1 from "./Design1";
import Design2 from "./Design2";
import Design3 from "./Design3";
import Design4 from "./Design4";

export default function MainLayout() {
    return (
        <div>                           
            <Design1/>                                      
            <Design2/>
            <Design3/>
            <Design4/>
        </div>
    );
}