export default function Design4() {
    const gridItems = [];
    for (let x = 0; x < 16; x++) {
        gridItems.push(
            <div key={x} style={{height: "100px", width: "24%", background: "gray"}}></div>
        );
    }
    return <div style={{margin:"50px 0"}}>     
        <h1>Layout 4</h1>
        <div style={{backgroundColor:"gray",color:'white',display:"flex",alignItems:"center"}}>
            <div style={{width:"50%"}}><h1>Logo</h1></div>
            <div style={{width:"50%"}}><p>Navigation</p></div>
        </div>
        <div style={{display:"flex",flexWrap:"wrap",gap:"20px",margin:"10px 0"}}>
            {gridItems}     
            {/* I try to write here previous js code of for loop but found errors i dont understand why this happen*/}           
        </div>
        <div style={{display:"flex",alignItems:"center",gap:"30px",margin:"10px 0"}}> 
            <div style={{backgroundColor:"gray",color:'white',width:"33%",height:"150px",display:"grid",placeContent:"center"}}>Box 1</div>
            <div style={{backgroundColor:"gray",color:'white',width:"33%",height:"150px",display:"grid",placeContent:"center"}}>Box 2</div>
            <div style={{backgroundColor:"gray",color:'white',width:"33%",height:"150px",display:"grid",placeContent:"center"}}>Box 3</div>
        </div>
        <div style={{backgroundColor:"gray",color:'white',margin:"5px 0",padding:"10px 0",textAlign:"center"}}>Footer</div>
    </div>
}