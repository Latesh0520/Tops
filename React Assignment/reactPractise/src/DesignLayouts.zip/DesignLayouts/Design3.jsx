export default function Design3() {
    return (
        <div style={{margin:"50px 0"}}>
            <h1>Layout 3</h1>
            <div style={{backgroundColor:"gray",color:'white'}}><h1>Logo</h1></div>
            <div style={{display:"flex",alignItems:"center",gap:"10px"}}> 
                <div style={{width:"20%",height:"500px"}}><h2> Side Bar</h2></div>
                <div style={{width:"80%",height:"500px",margin:"10px 0"}}>
                    <div style={{backgroundColor:"gray",color:'white',height:"100px",display:"grid",placeContent:"center",marginBottom:"5px"}}><p>Header / Banner</p></div>                     
                    <div style={{backgroundColor:"gray",color:'white',height:"395px",display:"grid",placeContent:"center"}}><h2>Body Text</h2></div>
                </div>
            </div>
            <div style={{backgroundColor:"gray",color:'white',margin:"5px 0",padding:"10px 0",textAlign:"center"}}>Footer</div>
        </div>
    );
}