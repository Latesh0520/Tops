export default function Design1() {
    return (
        <div style={{margin:"50px 0"}}>
            <h1>Layout 1</h1>
            <div style={{backgroundColor:"gray",color:'white'}}><h1>Logo</h1></div>
            <div style={{backgroundColor:"gray",color:'white',textAlign:"center",margin:"5px 0",padding:"5px 0"}}><p>Navigation</p></div>
            <div style={{backgroundColor:"gray",color:'white',height:"100px",display:"grid",placeContent:"center",margin:"5px 0"}}><p>Header / Banner</p></div>
            <div style={{display:"flex",alignItems:"center",gap:"10px"}}> 
                <div style={{backgroundColor:"gray",color:'white',width:"30%",height:"200px",}}>Side Bar</div>
                <div style={{backgroundColor:"gray",color:'white',width:"70%",height:"200px"}}>Body Area</div>
            </div>
            <div style={{backgroundColor:"gray",color:'white',margin:"5px 0",padding:"10px 0",textAlign:"center"}}>Footer</div>
        </div>
    );
}