export default function Design2() {
    return (
        <div style={{margin:"50px 0"}}>
            <h1>Layout 2</h1>
            <div style={{backgroundColor:"gray",color:'white',display:"flex",alignItems:"center"}}>
                <div style={{width:"50%"}}><h1>Logo</h1></div>
                <div style={{width:"50%"}}><p>Navigation</p></div>
            </div>
            <div style={{backgroundColor:"gray",color:'white',height:"100px",display:"grid",placeContent:"center",margin:"5px 0"}}><p>Header / Banner</p></div>
            <div style={{backgroundColor:"gray",color:'white',height:"100px",display:"grid",placeContent:"center",margin:"5px 0"}}><p>Intro text Area</p></div>
            <div style={{display:"flex",alignItems:"center",gap:"30px",margin:"10px 0"}}> 
                <div style={{backgroundColor:"gray",color:'white',width:"33%",height:"200px",display:"grid",placeContent:"center"}}>Box 1</div>
                <div style={{backgroundColor:"gray",color:'white',width:"33%",height:"200px",display:"grid",placeContent:"center"}}>Box 2</div>
                <div style={{backgroundColor:"gray",color:'white',width:"33%",height:"200px",display:"grid",placeContent:"center"}}>Box 3</div>
            </div>
            <div style={{backgroundColor:"gray",color:'white',margin:"5px 0",padding:"10px 0",textAlign:"center"}}>Footer</div>
        </div>
    );
}